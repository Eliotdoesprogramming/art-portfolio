package com.talentpath.artportfolio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArtPortfolioApplicationTests {

	@Test
	void contextLoads() {
	}

}
