package com.talentpath.artportfolio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArtPortfolioApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArtPortfolioApplication.class, args);
	}

}
